const config = {
    Host: "localhost",
    User: "root",
    Password: "debapriya",
    Database: "expense_tracker",
    Port: 3306
}
module.exports = config;