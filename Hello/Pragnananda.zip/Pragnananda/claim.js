function ajaxcall(){
	alert("running")

		$.ajax({
			url: 'http://localhost:8000/submit',
			type: 'post',
			contentType: 'application/html',
			data: JSON.stringify({
				empID: $("#empID").val(),
				projectManagerId: $("#projectManagerId").val(),
				typeofClaim: $("#typeofClaim").val(),
				noPerson: $("#noPerson").val(),
				amount: $("#amount").val(),
				invoiceFile: $("#invoiceFile").val(),
				comment: $("#comment").val()
			}),
			success: function (data) {
				console.log("ajax is working")
								
			}
		});
}